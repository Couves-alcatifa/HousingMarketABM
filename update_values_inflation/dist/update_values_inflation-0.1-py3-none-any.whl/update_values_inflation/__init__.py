# update_values_inflation/__init__.py
from update_values_inflation import adjust_value  # Import your functions here
